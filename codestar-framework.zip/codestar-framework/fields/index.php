<?php // Silence is golden.
