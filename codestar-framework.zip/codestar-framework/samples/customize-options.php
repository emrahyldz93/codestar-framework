<?php if (!defined('ABSPATH')) {
  die;
} // Cannot access directly.

//
// Set a unique slug-like ID
//
$prefix = 'pochi_settings';

//
// Create customize options
//
CSF::createCustomizeOptions($prefix);





CSF::createSection($prefix, array(
  'title'    =>  esc_html__('Header Settings', 'pochi'),
  
  'fields'   => array(

    array(
      'id'    => 'header-logo',
      'type'  => 'media',
      'title' =>  esc_html__('Header Logo', 'pochi'),
    ),
    array(
      'id'    => 'header-career',
      'type'  => 'text',
      'title' =>  esc_html__('Header Career Text', 'pochi'),
      'default' => 'Web & Mobile <br />Development',
    ),
    array(
      'id'    => 'header-career-url',
      'type'  => 'link',
      'title' =>  esc_html__('Header Career Url', 'pochi'),
     
    ),

    array(
      'id'    => 'header-phone',
      'type'  => 'text',
      'title' =>  esc_html__('Header Phone', 'pochi'),
      'default' => 'Call Me: (+334) 334 5563',
    ),
    array(
      'id'    => 'header-mail',
      'type'  => 'text',
      'title' =>  esc_html__('Header Mail', 'pochi'),
      'default' => 'info@jhondoe.com',
    ),

    array(
      'id'    => 'header-menu-img',
      'type'  => 'media',
      'title' =>  esc_html__('Mega Menu Image', 'pochi'),
    ),

    

  ),
  
));




//
// Create footer
// 

CSF::createSection($prefix, array(
  'title'    => esc_html__('Footer', 'pochi'),
  'priority' => 2,
  //'description' => esc_html__('If you do not enter the text, it will not appear', 'pochi'),
  'fields'   => array(

    array(
      'id'    => 'footer-logo',
      'type'  => 'media',
      'title' =>  esc_html__('Footer Logo', 'pochi'),
    ),
    array(
      'id'        => 'footer-social-icon',
      'type'      => 'group',
      'title'     =>  esc_html__('Social Accounts', 'pearl'),
      'fields'    => array(
        array(
          'id'    => 'icon',
          'type'  => 'icon',
          'title' =>  esc_html__('Icon Select', 'pearl'),
        ),
        array(
          'id'    => 'link',
          'type'  => 'text',
          'title' =>  esc_html__('Url Enter', 'pearl'),
        ),
   
      ),
      'default'   => array(
        array(
          'icon'     => 'fab fa-dribbble',
          'link'    => 'https://facebook.com',
          'color'  => 'fac'
        ),
        array(
          'icon'     => 'fab fa-behance',
          'link'    => 'https://twitter.com',
          'color'  => 'twi'
        ),
        array(
          'icon'     => 'fab fa-twitter ',
          'link'    => 'https://dribbble.com',
          'color'  => 'dri'
        ),
        array(
          'icon'     => 'fab fa-instagram',
          'link'    => 'https://instagram.com',
          'color'  => 'ins'
        ),
      ),
    ),


  )
));




//
// Create a Reset 
//
CSF::createSection($prefix, array(
  'title'    => 'Reset & Backup',
  'priority' => 3,
  'fields'   => array(

    array(
      'type'  => 'backup',
    ),

  ),
));
