<?php if (!defined('ABSPATH')) {
  die;
} // Cannot access directly.
// Control core classes for avoid errors
if (class_exists('CSF')) {
  //
  // Set a unique slug-like ID
  $prefix = 'metabox_options';
  //
  // Create a metabox
  CSF::createMetabox($prefix, array(
    'title'     => esc_html__('Portfolio Options', 'pearl'),
    'post_type' => 'portfolio',
    'context'   => 'normal', // The context within the screen where the boxes should display. `normal`, `side`, `advanced`
  ));
  //
  // Create a section
  CSF::createSection($prefix, array(
    //'title'  => 'Tab Title 1',
    'fields' => array(
      array(
        'type'    => 'subheading',
        'content' => 'Gallery',
      ),
      array(
        'id'    => 'portfolio-gallery',
        'type'  => 'gallery',
        'title' => esc_html__('Gallery', 'pearl'),
      ),
      array(
        'type'    => 'subheading',
        'content' => 'Project Settings',
      ),
      array(
        'id'        => 'information-group',
        'type'      => 'group',
        'title'     => esc_html__('Information Add', 'pearl'),
        'fields'    => array(
          array(
            'id'    => 'information-title',
            'type'  => 'text',
            'title' => esc_html__('Title', 'pearl'),
          ),
          array(
            'id'    => 'information-icon',
            'type'  => 'icon',
            'title' => esc_html__('Icon', 'pearl'),
          ),
          array(
            'id'    => 'information-content',
            'type'  => 'textarea',
            'title' => esc_html__('Content', 'pearl'),
          ),
        ),
        'default'   => array(
          array(
            'information-title'     => 'Start:',
            'information-icon'    => 'fas fa-project-diagram',
            'information-content' => 'October 26th, 2020',
          ),
          array(
            'information-title'     => 'Location:',
            'information-icon'    => 'fas fa-map-marker-alt',
            'information-content' => 'Mountain View CA 94043',
          ),
          array(
            'information-title'     => 'Complate:',
            'information-icon'    => 'fas fa-hourglass-start',
            'information-content' => 'November 29th, 2020',
          ),
          array(
            'information-title'     => 'Service',
            'information-icon'    => 'fas fa-layer-group',
            'information-content' => 'App mobile Development',
          ),
        ),
      ),
      array(
        'id'    => 'portfolio-view-project',
        'type'  => 'link',
        'title' => esc_html__('View Projct URL', 'pochi'),
      ),
     
 
    )
  ));
  //
  // Create a section
  /*  CSF::createSection( $prefix, array(
'title'  => 'Tab Title 2',
'fields' => array(
// A textarea field
array(
'id'    => 'opt-textarea',
'type'  => 'textarea',
'title' => 'Simple Textarea',
),
)
) );  */
}
